TODO: add information about contributions of team member(s)
Senuka & Caroline: Worked on the 5 functions for Milestone 1 (fixpoint_init, fixpoint_get_whole, fixpoint_get_frac, fixpoint_is_negative, fixpoint_negate). 
Milestone 2: 
Caroline and Senuka: add
Senuka: multiply, subtract
Caroline: compare, parse_hex, format_hex